import React from 'react'
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom'
import Calculator from './Components/UseContext/Calculator'
import Consumer1 from './Components/UseContext/Consumer1'
import Consumer2 from './Components/UseContext/Consumer2'
import Consumer3 from './Components/UseContext/Consumer3'
import Header from './Components/UseContext/Header'
import Provider from './Components/UseContext/Provider'
import SelfPractice from './Components/UseContext/SelfPractice'
import LocalStorage from './Components/LocalStorage/LocalStorage'


const App = () => {
  return (
    <>
  <Router>
  <Provider>
  <Header/>

 
    <Routes>
      <Route path='/' element={<Consumer1/>}/>
      <Route path='/Consumer2' element={<Consumer2/>}/>
      <Route path='/Consumer3' element={<Consumer3/>}/>
      <Route path='/Calculator' element={<Calculator/>}/>
      <Route path='/Cal' element={<SelfPractice/>}/>
      <Route path='/localstorage' element={<LocalStorage/>} />
    </Routes>
    </Provider>
  </Router>
    </>
  )
}

export default App
