import React from 'react'

function About() {
  return (
    
    <div className='container'>
      <h1 className='display-3 text-center'>About Us</h1>
      <p className=' text-center'>a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer</p>
      <div className="card-deck">
        <div className="card">
          <img className="card-img-top" style={{height:'40vh'}}  src="https://i.brecorder.com/primary/2022/12/6397be6830c1e.jpg" alt="Card image cap" />
          <div className="card-body">
            <h5 className="card-title">Imran Khan</h5>
            <p className="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            <p className="card-text"><small className="text-muted">Last updated 3 mins ago</small></p>
          </div>
        </div>
        <div className="card">
          <img className="card-img-top" style={{height:'40vh'}}  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCeSLUbb_3SfI1Fe2WZZeNPKKAgyrIKFVeAw&usqp=CAU" alt="Card image cap" />
          <div className="card-body">
            <h5 className="card-title">Obama</h5>
            <p className="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
            <p className="card-text"><small className="text-muted">Last updated 3 mins ago</small></p>
          </div>
        </div>
        <div className="card">
          <img className="card-img-top" style={{height:'40vh'}} src="https://www.politico.eu/cdn-cgi/image/width=1160,height=774,quality=80,onerror=redirect,format=auto/wp-content/uploads/2022/10/25/GettyImages-1436389160-scaled.jpg" alt="Card image cap" />
          <div className="card-body">
            <h5 className="card-title">Prime Minister</h5>
            <p className="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
            <p className="card-text"><small className="text-muted">Last updated 3 mins ago</small></p>
          </div>
        </div>
      </div>
        
  
</div>
  )
}

export default About