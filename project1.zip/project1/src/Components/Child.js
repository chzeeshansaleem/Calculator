import React, { Component } from 'react'

export class Child extends Component {
  render() {
    return (
      <div>Child</div>
    )
  }
}

export default Child