import React, { Component } from 'react'

export default class Child1 extends Component {
  
  constructor(props){
  
    super(props);
  
     this.state={
     model: "Mustang",
     color: "red",
     year: 1964};
    
  }
  
  changeColor = () => {
    this.setState({year: this.state.year+1});//Change The state in class Components
  }

  
  
  render() {
    return (
      <>
       <h1>Welcome to {this.state.model} {this.props.city}</h1>
        <h1>Welcome to {this.state.color} {this.props.city}</h1>
        <h1>Welcome to {this.state.year} {this.props.city} </h1>
       
       
        

       
        <button onClick={this.changeColor}>Change Color</button>


      </>
    )
  }
}
