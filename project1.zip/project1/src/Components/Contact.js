import React from 'react'
import About from './About'
import Services from './Services'

function Contact() {
  return (
    <div>
    <h1 className='display-3 text-center'>Contact Us</h1>
    <form className='w-25' style={{marginLeft:"37.5%"}}>
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">Email address</label>
          <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
          <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Message</label>
          <textarea type="text" className="form-control" id="exampleInputPassword1" placeholder="Enter Message.." />
        </div>
        <div className="form-group form-check">
          <input type="checkbox" className="form-check-input" id="exampleCheck1" />
          <label className="form-check-label" htmlFor="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" className="btn btn-primary text-center">Submit</button>
      </form> 
   
  </div>

  
  )
}

export default Contact