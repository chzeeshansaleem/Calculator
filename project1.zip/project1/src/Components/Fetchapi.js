import React,{useState,useEffect} from 'react'

function Fetchapi() {
  const [data, setData] = useState([]);

  const api = async () => {
    await fetch("https://fakestoreapi.com/products")
      .then((res) => res.json())
      .then((user) => {
        setData(user);
        console.log(data);
      });
  };

  useEffect(() => {
    api();
  }, []);

  return (
    <div className="container">
      <table className="table table-bordered">
        <thead>
          <tr >
          
            <th>Id</th>
            <th>Title</th>
            <th>Price</th>
            <th>Description</th>
            <th>catogery</th>
            <th rowSpan={2}>Image</th>
            <th colSpan={2}>Rating
          
            </th>

          </tr>
          <tr>
              
             <td colSpan={6}></td>
             <td>Count</td>
             <td>Rating</td>
            </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr>
              
              <td>{item.id}</td>
              <td>{item.title}</td>
              <td>${item.price}</td>
              <td>{item.description}</td>
              
              <td>{item.category}</td>
              <td><img src="{item.image}" /></td>
              <td>{item.rating.count}</td>
              <td>{item.rating.rate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Fetchapi