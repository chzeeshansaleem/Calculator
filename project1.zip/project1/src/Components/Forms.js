import React, { useState } from 'react'

const Forms = () => {
    const [inputs, setInputs] = useState([]);
    const [city, setCity] = useState("choose City");
   
    const changeCity = (e) => {
      setCity(e.target.value);
    }
    
  
  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setInputs(values => ({...values, [name]: value}))
    console.log(inputs)
  }

  const handleSubmit = (event) => {
    event.preventDefault();
  console.log(inputs.username);
  console.log(inputs.text);
  }

  return (
    <>
    
    <form onSubmit={handleSubmit}>
      <label>Enter your name:
      <input 
        type="text" 
        name="username" 
        value={inputs.username} 
        onChange={handleChange}
      />
      </label>
      <label>Enter your age:
        <input 
          type="number" 
          name="age" 
          value={inputs.age} 
          onChange={handleChange}
        />
        </label>
        <input type="submit" />
        <select  value={city}  onChange={changeCity}>
    <option value="Lahore">Lahore</option>
    <option value="Karchi">Karchi</option>
    <option value="Gujranwala">Gujranwala</option>

 </select>
    </form>
    <textarea name="text" 
          value={inputs.text} onChange={handleChange}/>
 
    </>
  )
}

export default Forms