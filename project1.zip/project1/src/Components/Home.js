import React from 'react'

function Home() {
  return (
    <div id='header1' className='d-flex align-items-center justify-content-center' >
    <div className='w-50' >
    <h1 className='text-center text-white display-5 font-weight-bold pb-3 '>Welcome to React Project</h1>
       <p  className='text-center font-weight-bold text-white display-5 lead mx-5 font-weight-100 '>uaerat distinctio sed id ratione est alias voluptatum numquam tempore harum quas mollitia enim,
       <button className='btn btn-primary w-25 px-2 mt-2 text-center'>Discover</button> </p>
      
    </div>
    
    </div>
  )
}

export default Home;