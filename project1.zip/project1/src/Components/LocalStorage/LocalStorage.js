import React, { useEffect, useState } from "react";

const LocalStorage = () => {
  // state for handling the localstorage data
  const [data, setData] = useState([]);

  //state for getting the form data
  const [newData, setnewData] = useState("");
// Add data function
  const addData = (mynewdata) => {
    localStorage.setItem("task", JSON.stringify(mynewdata));
  };
// Save data click Function
  const onClick = () => {
    const newdata = [...data, { new: newData, id: Date.now() }];
    addData(newdata);
    setData(newdata);
  };
// use effect state  for re rendring 
  useEffect(() => {
    setData(JSON.parse(localStorage.getItem("task")));
  }, []);
  return (
    <div className="container">
      <h2 className="text-center display-3">Welcome to the LocalStorage</h2>

      <label>Enter Your Name</label>

      <input
        type="text"
        onChange={(e) => setnewData(e.target.value)}
        className="form-control"
      />

      <button onClick={onClick} className="btn btn-primary mt-3">
        Save Data
      </button>

      <hr />
      <table className="table table-bordered">
      <tr>
        <td>Id</td>
        <td>Name</td>
        <td>Action</td>

      </tr>
      {data.map((pro) => (
        <tr>
         <td> {pro.id}</td>
         <td> {pro.new}</td>
       <td>  <button className="btn btn-danger">Delete</button></td>
        </tr>
      ))}</table>
    </div>
  );
};

export default LocalStorage;
