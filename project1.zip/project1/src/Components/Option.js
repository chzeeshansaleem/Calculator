import React, { useState } from 'react'

const Option = () => {
    const [myCar, setMyCar] = useState("Choose Option");

  const handleChange = (event) => {
    setMyCar(event.target.value)
  }

  return (
    <form>
      <select value={myCar} onChange={handleChange}>
      <option disabled value="Choose Option">Choose Option</option>
        <option value="Ford">Ford</option>
        <option value="Volvo">Volvo</option>
        <option value="Fiat">Fiat</option>
      </select>
    </form>
  )
}

export default Option
