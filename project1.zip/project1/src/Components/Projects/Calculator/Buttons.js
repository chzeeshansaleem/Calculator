import React, { useContext } from 'react'
import "./Calculator.css";
import { CreateContext } from './Provider';

const Buttons = (props) => {
    const a=useContext(CreateContext)
  return (
    <div>
      <input className="btn btn-primary btn1" type="button" value={props.lable} onClick={() =>a.handleBtn(props.lable)} />
    </div>
  )
}

export default Buttons
