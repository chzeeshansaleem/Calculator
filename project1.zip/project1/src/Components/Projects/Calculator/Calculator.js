import React, { useContext } from "react";
import "./Calculator.css";
import Buttons from './Buttons'
import { CreateContext } from "./Provider";
import EqualBtn from "./EqualBtn";
import ResetBtn from "./ResetBtn";
const Calculator = () => {
    const a=useContext(CreateContext)

    return (
        <div>
          <div className=" d-flex justify-content-center ">
           <div className="output bg-danger">
            <input className="form-control border-0 mt-1 bg-danger" type="text" onChange={a.handle} value={a.myOutput} readOnly/>
            <p className="text-center">{a.output}</p>
           </div>
            
          </div>
            <div className=" d-flex justify-content-center">
           <ResetBtn lable={"C"} />
           <Buttons lable={"00"} />
           <Buttons lable={"%"} />
           <Buttons lable={"/"} />
            
          </div>
          <div className=" d-flex justify-content-center">
           <Buttons lable={"*"}/>
           <Buttons lable={"9"}/>
           <Buttons lable={"8"}/>
           <Buttons lable={"7"}/>
            
          </div>
          <div className=" d-flex justify-content-center">
           <Buttons lable={"-"}/>
           <Buttons lable={"6"}/>
           <Buttons lable={"5"}/>
           <Buttons lable={"4"}/>
            
          </div>
          <div className=" d-flex justify-content-center">
           <Buttons lable={"+"}/>
           <Buttons lable={"3"}/>
           <Buttons lable={"2"}/>
           <Buttons lable={"1"}/>
            
          </div>
          <div className=" d-flex justify-content-center">
           <EqualBtn lable={"="}/>
           <Buttons lable={"."}/>
           <Buttons lable={"0"}/>
           <Buttons lable={""} />
            
          </div>
        </div>
      )
};

export default Calculator;
