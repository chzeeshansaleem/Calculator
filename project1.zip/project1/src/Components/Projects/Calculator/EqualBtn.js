import React, { useContext } from 'react'
import { CreateContext } from './Provider'

const EqualBtn = (props) => {
    const a=useContext(CreateContext)
  return (
    <>
     <input className="btn btn-primary btn1" type="button" value={props.lable} onClick={() =>a.ans()} /> 
    </>
  )
}

export default EqualBtn
