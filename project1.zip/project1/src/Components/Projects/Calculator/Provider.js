import React, { createContext, useRef, useState } from "react";

export const CreateContext = createContext();

const Provider = (Props) => {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const handle = (e) => {
    setInput(e.target.value)
  }
  
  const prevCountRef = useRef();
  prevCountRef.current=input;
  const handleBtn =(e) => {
  
    setInput(input+e)
  };
  const ans = () => {
    console.log("Clicked")
    setOutput(eval(input));
  }
  const reset = () => {
    setInput("")
    setOutput("")
  }
  
  return (
    <div>
      <CreateContext.Provider
        value={{
          myOutput: input,
          handleBtn:handleBtn,
          handle:handle,
          ans: ans,
          output:output,
          reset:reset,
        }}
      >
        {Props.children}
      </CreateContext.Provider>
    </div>
  );
};

export default Provider;
