import React, { useContext } from 'react'
import { CreateContext } from './Provider'
const ResetBtn = (props) => {
    const a=useContext(CreateContext)
  return (
    <>
      <input className="btn btn-primary btn1" type="button" value={props.lable} onClick={() =>a.reset()} /> 
    </>
  )
}

export default ResetBtn
