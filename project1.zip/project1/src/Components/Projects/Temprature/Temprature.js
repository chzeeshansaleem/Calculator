import React, { useState } from "react";
import "./Temp.css";
const Temprature = () => {
  const [temp, setTemp] = useState("10");
  const [tempColor, setTempColor] = useState('cold');
  
  const TempIncreament = () => {
    const temps=temp + 1;
    if(temps>=16){
      setTempColor("hot")
    }
    setTemp(temps);
  };

  const Tempdecreament = () => {
    const tempd=temp - 1;
    if(tempd<10){
      setTempColor("cold")
    }
    setTemp(tempd);
  };


  return (
    <>
      <div
        className="container bg-dark d-flex flex-column justify-content-center align-items-center"
        id="outer"
      >
        <h3 className="text-white">Temprature Control</h3>
        <div
          className={` rounded-circle text-center display-3  font-weight-bold ${tempColor}`}
          id="inner"
        >
          {temp}C
        </div>

        <button
          className="btn btn-primary rounded-circle p-3 mt-4"
          onClick={Tempdecreament}
        >
          -
        </button>
        <button
          className="btn btn-primary rounded-circle p-3 mt-3 "
          onClick={TempIncreament}
        >
          +
        </button>
      </div>
    </>
  );
};

export default Temprature;
