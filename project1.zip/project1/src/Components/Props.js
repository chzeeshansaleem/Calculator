import React from 'react'

function Props(Prop) {
  return (
    <div>
        <h1>This Plus Countdown from {Prop.data}</h1>
        <button onClick={Prop.Counts}>Click me</button>
    </div>
  )
}

export default Props