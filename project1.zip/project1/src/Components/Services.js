import React from 'react'

function Services() {
  return (
    <div>
      <h1 className='display-3 text-center'>Sevices</h1>
      <div className='d-flex justify-content-around container-fluid'>
      <div><h1>Our Courses</h1>
      <ul>
        <li>Web Development</li>
        <li>Java Development</li>
        <li>C++ Development</li>

        <li>MERN Stack</li>
        <li>Full Stack</li>

      </ul>
      </div>
      <div style={{marginLeft:"20px"}} className='border-right border-success'></div>
      <div><h1>Our Students Work</h1>
      <ul>
        <li>Devsinc</li>
        <li>Systems Limited</li>
        <li>Google</li>

        <li>MicroSoft</li>
        <li>ArbiSoft</li>

      </ul></div>
  
    </div>
    </div>
  )
}

export default Services