import React, { useContext } from "react";
import { CreateContext } from "./Provider";

const Consumer1 = () => {
  const a = useContext(CreateContext);
  a.incre = () => {
    console.log("Cliked")
  return  a.setCount(a.Count+1)
  }
  
  return (
    <div>
      {/* My name is {a.data}
      my api id is{" "}
      {a.Api.map((item) => {
          return  <ul>
            <li>{item.id}</li>
          </ul>
          
      })}
     <button onClick={a.name}>Change Name</button> */}

   
    </div>
  );
};

export default Consumer1;
