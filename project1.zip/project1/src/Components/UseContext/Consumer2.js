import React from 'react'

const Consumer2 = () => {
  return (
    <div>
     Consumer2 
    </div>
  )
}

export default Consumer2
