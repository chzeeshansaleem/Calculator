import React, { useContext } from 'react'
import { CreateContext } from './Provider'
const Consumer3 = () => {
    const a=useContext(CreateContext)
  return (
    <div>
    <p>Counter Start From {a.myCount}</p>
    <button onClick={a.infun}>add</button>
    <button onClick={a.defun}>minus</button>
    <button onClick={a.emfun}>empty</button>
    </div>
  )
}

export default Consumer3
