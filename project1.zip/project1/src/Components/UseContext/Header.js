import React, { useContext } from 'react'
import { CreateContext } from './Provider'
import { Link } from 'react-router-dom'
const Header = () => {
    const a=useContext(CreateContext)
  return (
    <div>
      <nav className="navbar navbar-expand-sm bg-light navbar-light">
  <ul className="navbar-nav">
    <li className="nav-item active">
      <Link className="nav-link" to="/">Consumer1</Link>
    </li>
    <li className="nav-item">
      <Link className="nav-link" to="/Consumer2">Consumer2</Link>
    </li>
    <li className="nav-item">
      <Link className="nav-link" to="/Consumer3">Consumer3</Link>
    </li>
    <li className="nav-item">
      <Link className="nav-link" to="/localstorage">LocalStorage</Link>
    </li>
    <li style={{float:"right"}}>
    <button type="button" className="btn btn-primary">
  Add Cart <span className="badge badge-light">{a.myCount}</span>

</button>
    </li>
    <li className="nav-item">
      <Link className="nav-link" to="/Calculator">Calculator</Link>
    </li>
  </ul>
</nav>
    </div>
  )
}

export default Header
