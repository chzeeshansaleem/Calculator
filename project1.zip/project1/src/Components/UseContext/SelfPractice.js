import React from 'react'
import Buttons from './Buttons'

const SelfPractice = () => {
  return (
    <div>
        <div className=" d-flex justify-content-center">
       <Buttons lable={"C"}/>
       <Buttons lable={"AC"}/>
       <Buttons lable={"%"}/>
       <Buttons lable={"/"}/>
        
      </div>
      <div className=" d-flex justify-content-center">
       <Buttons lable={"*"}/>
       <Buttons lable={"9"}/>
       <Buttons lable={"8"}/>
       <Buttons lable={"7"}/>
        
      </div>
      <div className=" d-flex justify-content-center">
       <Buttons lable={"-"}/>
       <Buttons lable={"6"}/>
       <Buttons lable={"5"}/>
       <Buttons lable={"4"}/>
        
      </div>
      <div className=" d-flex justify-content-center">
       <Buttons lable={"+"}/>
       <Buttons lable={"3"}/>
       <Buttons lable={"2"}/>
       <Buttons lable={"1"}/>
        
      </div>
    </div>
  )
}

export default SelfPractice
